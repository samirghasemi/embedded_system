/*
 * File: p301_types.h
 *
 * Code generated for Simulink model 'p301'.
 *
 * Model version                  : 1.25
 * Simulink Coder version         : 9.5 (R2021a) 14-Nov-2020
 * C/C++ source code generated on : Mon Jan  3 15:19:34 2022
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Atmel->AVR
 * Code generation objectives:
 *    1. Execution efficiency
 *    2. Traceability
 * Validation result: Not run
 */

#ifndef RTW_HEADER_p301_types_h_
#define RTW_HEADER_p301_types_h_

/* Model Code Variants */

/* Forward declaration for rtModel */
typedef struct tag_RTM_p301_T RT_MODEL_p301_T;

#endif                                 /* RTW_HEADER_p301_types_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
