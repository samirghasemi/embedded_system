/*
 * File: p31_private.h
 *
 * Code generated for Simulink model 'p31'.
 *
 * Model version                  : 1.20
 * Simulink Coder version         : 9.5 (R2021a) 14-Nov-2020
 * C/C++ source code generated on : Sun Dec 12 15:56:39 2021
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Atmel->AVR
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_p31_private_h_
#define RTW_HEADER_p31_private_h_
#include "rtwtypes.h"
#endif                                 /* RTW_HEADER_p31_private_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
